The firmware utilities allow for flashing the puzzlebot firmware and SPIFFS file system data on the ESP32 chip.

Run the script files for the corresponding operating system (Windows, Linux).

The binary files contain the default "config.yaml" configuration file.
The config file can be edited as follows:
 - connect to the robot access point;
 - open: "http:\\192.168.1.1\config";

