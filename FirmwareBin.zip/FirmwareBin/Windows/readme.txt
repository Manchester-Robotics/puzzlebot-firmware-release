Commands:

Run DataFlash.bat      : flashes the data files to the esp32
Run FirmwareFlash.bat  : flashes the firmware to the esp32
