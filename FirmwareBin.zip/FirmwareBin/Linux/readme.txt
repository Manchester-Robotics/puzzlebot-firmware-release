Commands:

./DataFlash.sh      : flashes the data files to the esp32
./FirmwareFlash.sh  : flashes the firmware to the esp32

Set permission to be executed in properties to both files.

